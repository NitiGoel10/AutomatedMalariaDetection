
const MALARIA_CLASSES = {
  0: 'non-infected',
  1: 'infected',
};